t1 = x * 8
y = t1