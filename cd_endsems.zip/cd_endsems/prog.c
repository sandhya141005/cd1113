t1 = 2 + 3
a = t1
t2 = a * 1
t3 = a + 0